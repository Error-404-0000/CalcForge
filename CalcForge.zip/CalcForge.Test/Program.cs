﻿using CalcForge;
using CalcForge.Compiler;

var e = new Evaluator(@"
0*0
if (eq 0)
{
    
    +200*2-89
}
if (neq 0)
{
   + 12-28
    
}*6
");
Console.WriteLine(e.Evaluate());
Debugger.WriteTree(e.OptimizedTokens);
