﻿namespace CalcForge.Compiler
{
    //tells the Compiler what side of the token is needed
    public enum CompileNeeds
    {
        None,
        Value,
        Left,
        Right,
        Token
    }


}
