﻿namespace CalcForge;
public enum TokenTree
{
    Single,
    Group
}
