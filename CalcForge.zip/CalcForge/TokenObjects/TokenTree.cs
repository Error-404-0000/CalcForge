﻿namespace CalcForge.TokenObjects;
public enum TokenTree
{
    Single,
    Group
}
