﻿namespace CalcForge.Func;

// holds a function token
public record FunctionData(string FunctionName, string[] @params);
